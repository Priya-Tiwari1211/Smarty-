<?php
    require("../libs/Smarty.class.php");
    $smarty=new Smarty();
    $smarty->assign('arr',array(
        array('name'=>'raj','class'=>'MCA'),
        array('name'=>'sam','class'=>'BBA')
    ));
    $smarty->display('sec.tpl');
    ?>