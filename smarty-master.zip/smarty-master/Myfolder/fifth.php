<?php 
 require("../libs/Smarty.class.php");
 $smarty=new Smarty();
// assign options arrays


// assign an array of data
$smarty->assign('articleTitle',
                "'Stiff Opposition Expected to Casketless Funeral Plan'"
                );
$smarty->assign('EmailAddress','smarty@example.com');


// display it
$smarty->display('fifth.tpl');
?>