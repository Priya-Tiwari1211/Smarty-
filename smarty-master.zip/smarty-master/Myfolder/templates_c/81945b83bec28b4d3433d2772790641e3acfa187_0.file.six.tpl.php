<?php
/* Smarty version 3.1.39, created on 2021-11-15 05:14:40
  from 'C:\xampp\htdocs\smarty-master\smarty-master\Myfolder\templates\six.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6191deb022f413_95938853',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '81945b83bec28b4d3433d2772790641e3acfa187' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty-master\\smarty-master\\Myfolder\\templates\\six.tpl',
      1 => 1636949677,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6191deb022f413_95938853 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp\\htdocs\\smarty-master\\smarty-master\\libs\\plugins\\modifier.replace.php','function'=>'smarty_modifier_replace',),));
?>

<?php echo $_smarty_tpl->tpl_vars['articleTitle']->value;?>

<?php echo preg_replace('!<[^>]*?>!', ' ', $_smarty_tpl->tpl_vars['articleTitle']->value);?>
 <?php echo strip_tags($_smarty_tpl->tpl_vars['articleTitle']->value);?>


<?php echo $_smarty_tpl->tpl_vars['articleTitle']->value;?>

<?php echo smarty_modifier_replace($_smarty_tpl->tpl_vars['articleTitle']->value,'Garden','Vineyard');?>

<?php echo smarty_modifier_replace($_smarty_tpl->tpl_vars['articleTitle']->value,' ','   ');
}
}
