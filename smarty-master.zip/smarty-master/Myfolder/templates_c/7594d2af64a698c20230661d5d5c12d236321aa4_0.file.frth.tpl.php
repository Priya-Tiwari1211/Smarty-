<?php
/* Smarty version 3.1.39, created on 2021-11-15 05:22:23
  from 'C:\xampp\htdocs\smarty-master\smarty-master\Myfolder\templates\frth.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6191e07f8975f2_11193502',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7594d2af64a698c20230661d5d5c12d236321aa4' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty-master\\smarty-master\\Myfolder\\templates\\frth.tpl',
      1 => 1636950137,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6191e07f8975f2_11193502 (Smarty_Internal_Template $_smarty_tpl) {
echo $_smarty_tpl->tpl_vars['articleTitle']->value;?>

<?php echo preg_match_all("#\w[\.\?\!](\W|$)#Su", $_smarty_tpl->tpl_vars['articleTitle']->value, $tmp);?>



<ul>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['myColors']->value, 'color');
$_smarty_tpl->tpl_vars['color']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['color']->value) {
$_smarty_tpl->tpl_vars['color']->do_else = false;
?>
    <li><?php echo $_smarty_tpl->tpl_vars['color']->value;?>
</li>
<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</ul>
<?php }
}
