<?php
/* Smarty version 3.1.39, created on 2021-11-11 18:23:24
  from 'C:\xampp\htdocs\smarty-master\smarty-master\Myfolder\templates\sec.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_618d518c06b4d9_64069611',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c742f1884e1db586bf566f50a2ac69306b51609f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty-master\\smarty-master\\Myfolder\\templates\\sec.tpl',
      1 => 1636651403,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_618d518c06b4d9_64069611 (Smarty_Internal_Template $_smarty_tpl) {
?><html>
<body>
<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['arr']->value, 'item');
$_smarty_tpl->tpl_vars['item']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['item']->value) {
$_smarty_tpl->tpl_vars['item']->do_else = false;
?>
    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['item']->value, 'v', false, 'k');
$_smarty_tpl->tpl_vars['v']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['k']->value => $_smarty_tpl->tpl_vars['v']->value) {
$_smarty_tpl->tpl_vars['v']->do_else = false;
?>
        <?php echo $_smarty_tpl->tpl_vars['k']->value;
echo $_smarty_tpl->tpl_vars['v']->value;?>

    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
</body>
</html><?php }
}
