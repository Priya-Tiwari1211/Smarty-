<?php
/* Smarty version 3.1.39, created on 2021-11-15 05:21:26
  from 'C:\xampp\htdocs\smarty-master\smarty-master\Myfolder\templates\eight.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6191e0469e58c4_41622388',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '016a697cf57721762216e656c0f959a99b238e56' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty-master\\smarty-master\\Myfolder\\templates\\eight.tpl',
      1 => 1636950070,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6191e0469e58c4_41622388 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp\\htdocs\\smarty-master\\smarty-master\\libs\\plugins\\modifier.mb_wordwrap.php','function'=>'smarty_modifier_mb_wordwrap',),));
echo $_smarty_tpl->tpl_vars['articleTitle']->value;?>


<?php echo smarty_modifier_mb_wordwrap($_smarty_tpl->tpl_vars['articleTitle']->value,30,"\n",false);?>


<?php echo smarty_modifier_mb_wordwrap($_smarty_tpl->tpl_vars['articleTitle']->value,20,"\n",false);?>


<?php echo smarty_modifier_mb_wordwrap($_smarty_tpl->tpl_vars['articleTitle']->value,30,"<br />\n",false);?>


<?php echo smarty_modifier_mb_wordwrap($_smarty_tpl->tpl_vars['articleTitle']->value,26,"\n",true);
}
}
