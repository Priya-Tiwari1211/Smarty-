<?php
/* Smarty version 3.1.39, created on 2021-11-15 05:13:20
  from 'C:\xampp\htdocs\smarty-master\smarty-master\Myfolder\templates\fifth.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6191de6030bb67_10697319',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '524932b783fd09a02af44c926f51a3ca9520acb1' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty-master\\smarty-master\\Myfolder\\templates\\fifth.tpl',
      1 => 1636949499,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6191de6030bb67_10697319 (Smarty_Internal_Template $_smarty_tpl) {
echo $_smarty_tpl->tpl_vars['articleTitle']->value;?>

'Stiff Opposition Expected to Casketless Funeral Plan'

<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['articleTitle']->value, ENT_QUOTES, 'UTF-8', true);?>

&#039;Stiff Opposition Expected to Casketless Funeral Plan&#039;

<?php echo htmlspecialchars($_smarty_tpl->tpl_vars['articleTitle']->value, ENT_QUOTES, 'UTF-8', true);?>
    &#039;Stiff Opposition Expected to Casketless Funeral Plan&#039;<?php }
}
