<?php
/* Smarty version 3.1.39, created on 2021-11-11 18:08:29
  from 'C:\xampp\htdocs\smarty-master\smarty-master\Myfolder\templates\1st.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_618d4e0d57e9d3_13624043',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7e5385d4525e547d9b33d5f84603db0cddd80219' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty-master\\smarty-master\\Myfolder\\templates\\1st.tpl',
      1 => 1636650434,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_618d4e0d57e9d3_13624043 (Smarty_Internal_Template $_smarty_tpl) {
?><html>
<body>
<h1><?php echo $_smarty_tpl->tpl_vars['name']->value;?>
</h1>
</body>
</html><?php }
}
