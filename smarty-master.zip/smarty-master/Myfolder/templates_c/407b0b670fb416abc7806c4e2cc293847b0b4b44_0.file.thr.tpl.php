<?php
/* Smarty version 3.1.39, created on 2021-11-15 05:07:36
  from 'C:\xampp\htdocs\smarty-master\smarty-master\Myfolder\templates\thr.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6191dd082784c8_90900591',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '407b0b670fb416abc7806c4e2cc293847b0b4b44' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty-master\\smarty-master\\Myfolder\\templates\\thr.tpl',
      1 => 1636949172,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6191dd082784c8_90900591 (Smarty_Internal_Template $_smarty_tpl) {
echo $_smarty_tpl->tpl_vars['Contacts']->value['fax'];?>
<br />
<?php echo $_smarty_tpl->tpl_vars['Contacts']->value['email'];?>
<br />
<?php echo $_smarty_tpl->tpl_vars['Contacts']->value['phone']['home'];?>
<br />
<?php echo $_smarty_tpl->tpl_vars['Contacts']->value['phone']['cell'];?>
<br /><?php }
}
