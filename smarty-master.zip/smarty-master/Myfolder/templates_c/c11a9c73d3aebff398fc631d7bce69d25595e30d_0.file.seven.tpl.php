<?php
/* Smarty version 3.1.39, created on 2021-11-15 05:19:33
  from 'C:\xampp\htdocs\smarty-master\smarty-master\Myfolder\templates\seven.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6191dfd563f111_95617441',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c11a9c73d3aebff398fc631d7bce69d25595e30d' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty-master\\smarty-master\\Myfolder\\templates\\seven.tpl',
      1 => 1636949971,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6191dfd563f111_95617441 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_checkPlugins(array(0=>array('file'=>'C:\\xampp\\htdocs\\smarty-master\\smarty-master\\libs\\plugins\\function.counter.php','function'=>'smarty_function_counter',),));
?>

<?php echo smarty_function_counter(array('start'=>0,'skip'=>2),$_smarty_tpl);?>
<br />
<?php echo smarty_function_counter(array(),$_smarty_tpl);?>
<br />
<?php echo smarty_function_counter(array(),$_smarty_tpl);?>
<br />
<?php echo smarty_function_counter(array(),$_smarty_tpl);?>
<br />
<?php $_template = new Smarty_Internal_Template('eval:'.$_smarty_tpl->tpl_vars['foo']->value, $_smarty_tpl->smarty, $_smarty_tpl);echo $_template->fetch(); ?>




<?php }
}
