
<?php
 require("../libs/Smarty.class.php");
 $smarty=new Smarty();
$smarty->assign('articleTitle',
                "Blind woman gets new kidney from dad she hasn't seen in years."
               );
               $smarty->display('eight.tpl');
?>