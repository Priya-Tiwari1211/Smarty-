<?php 
 require("../libs/Smarty.class.php");
 $smarty=new Smarty();
// assign options arrays

$smarty->assign('articleTitle',
                 'Two Soviet Ships Collide - One Dies.
                 Enraged Cow Injures Farmer with Axe.'
                 );
                 $arr = array('red', 'green', 'blue');
                 $smarty->assign('myColors', $arr);
// display it
$smarty->display('frth.tpl');
?>