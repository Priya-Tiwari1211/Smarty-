<?php
    require("../libs/Smarty.class.php");
    $Smarty=new Smarty();
    $Smarty->assign('name','Priya');
    $Smarty->display('1st.tpl');
    ?>