<?php 
 require("../libs/Smarty.class.php");
 $smarty=new Smarty();
// assign options arrays
$smarty->assign('articleTitle',
                "Blind Woman Gets <font face=\"helvetica\">New
Kidney</font> from Dad she Hasn't Seen in <b>years</b>."
               );


               $smarty->assign('articleTitle', "Child's Stool Great for Use in Garden.");
// display it
$smarty->display('six.tpl');
?>