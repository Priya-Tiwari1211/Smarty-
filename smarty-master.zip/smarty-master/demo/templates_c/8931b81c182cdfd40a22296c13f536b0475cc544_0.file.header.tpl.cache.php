<?php
/* Smarty version 3.1.39, created on 2021-08-16 05:11:25
  from 'C:\xampp\htdocs\smarty-master\demo\templates\header.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6119d75d801665_18346295',
  'has_nocache_code' => true,
  'file_dependency' => 
  array (
    '8931b81c182cdfd40a22296c13f536b0475cc544' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty-master\\demo\\templates\\header.tpl',
      1 => 1621925286,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6119d75d801665_18346295 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '3678098586119d75d7d19e3_05583604';
?>
<HTML>
<HEAD>
<TITLE><?php echo $_smarty_tpl->tpl_vars['title']->value;?>
 - <?php echo '/*%%SmartyNocache:3678098586119d75d7d19e3_05583604%%*/<?php echo $_smarty_tpl->tpl_vars[\'Name\']->value;?>
/*/%%SmartyNocache:3678098586119d75d7d19e3_05583604%%*/';?>
</TITLE>
</HEAD>
<BODY bgcolor="#ffffff">
<?php }
}
