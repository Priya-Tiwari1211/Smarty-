<?php
/* Smarty version 3.1.39, created on 2021-08-16 05:11:25
  from 'C:\xampp\htdocs\smarty-master\demo\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.39',
  'unifunc' => 'content_6119d75d977cb3_20552699',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '288ce4a8dacd5a4140ade241b16169a0e2d0701a' => 
    array (
      0 => 'C:\\xampp\\htdocs\\smarty-master\\demo\\templates\\footer.tpl',
      1 => 1621925286,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6119d75d977cb3_20552699 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->compiled->nocache_hash = '11761379896119d75d9472c1_24056424';
?>
</BODY>
</HTML>
<?php }
}
